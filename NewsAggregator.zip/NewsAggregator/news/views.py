from django.shortcuts import render,redirect
from django.conf import settings
from django.http import HttpResponse
import requests
from bs4 import BeautifulSoup
#from wordcloud import WordCloud 
import matplotlib.pyplot as plt 
import numpy as npy 
import json
import pandas as pd


# GEtting news from Times of India

toi_r = requests.get("https://timesofindia.indiatimes.com/briefs")
toi_soup = BeautifulSoup(toi_r.content, 'html5lib')

#toi_headings = toi_soup.find_all('div', class_='brief_box')
toi_headings = toi_soup.find_all("h2")

toi_headings = toi_headings[0:-13] # removing footers

toi_news = []

for th in toi_headings:
    toi_news.append(th.text)


#with open('django_news1.txt', 'w') as f:
 #   f.write(json.dumps(toi_news))

#text_as_string = open('django_news1.txt', 'r').read()

#wordcloud = WordCloud(collocations=False,width=600,height=400,background_color="white").generate(text_as_string)
#plt.imshow(wordcloud, interpolation = 'bilinear')
#plt.axis("off")
#plt.show()

#Getting news from Zee News

zn_r = requests.get("https://zeenews.india.com/")
zn_soup = BeautifulSoup(zn_r.content, 'html5lib')
zn_heading = zn_soup.findAll("h3")  
zn_heading = zn_heading[0:-10]


zn_news = []

for zn in zn_heading:
    zn_news.append(zn.text)


   

#Getting news from NDTV News

bb_r = requests.get("https://www.ndtv.com/latest?pfrom=home-mainnavgation")
bb_soup = BeautifulSoup(bb_r.content, 'html5lib')
#bb_heading = bb_soup.findAll('div',class_='new_storylising_contentwrap')  
bb_heading = bb_soup.findAll("h2") 
#bb_heading = bb_heading[0:-20]

bb_news = []

for bb in bb_heading:
    bb_news.append(bb.text)


#Getting news from NDTV News

nd_r = requests.get("https://www.ndtv.com/latest?pfrom=home-mainnavgation")
nd_soup = BeautifulSoup(nd_r.content, 'html5lib')
nd_heading = nd_soup.findAll('div',class_='new_storylising_contentwrap')  
#bb_heading = bb_soup.findAll("h2") 
#bb_heading = bb_heading[0:-20]

nd_news = []

for nd in nd_heading:
    nd_news.append(nd.text)
    

# GEtting news from Times of India

to_r = requests.get("https://timesofindia.indiatimes.com/briefs")
to_soup = BeautifulSoup(to_r.content, 'html5lib')

to_headings = to_soup.find_all('div', class_='brief_box')

#toi_headings = toi_soup.find_all("h2")

to_news = []


for th in to_headings:
    to_news.append(th.text)     



#########################sports circket
data=requests.get("https://inshorts.com/en/read/cricket")
soup=BeautifulSoup(data.content,'html.parser')

sports = soup.find_all('div',class_=["news-card-content news-right-box"])


news_content=[]


for sp in sports :
    news_content.append(sp.text)  
#print(news_content )   

############################################Sports Badminton
bd_data=requests.get("https://inshorts.com/en/read/badminton")
bd_soup=BeautifulSoup(data.content,'html.parser')

bd_sports = bd_soup.find_all('div',class_=["news-card-content news-right-box"])


news_bd_content=[]


for spb in sports :
    news_bd_content.append(spb.text)  
#print(news_bd_content )
        
###################################################Technology news###########
tech_data=requests.get("https://inshorts.com/en/read/technology")
tech_soup=BeautifulSoup(tech_data.content,'html.parser')

tech_news = tech_soup.find_all('div',class_=["news-card-content news-right-box"])


news_tech_content=[]


for tech in tech_news :
    news_tech_content.append(tech.text)
  
#print(news_tech_content)

#####################################Technology news from google news=================
tech_url=requests.get("https://news.google.com/topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRGRqTVhZU0FtVnVHZ0pKVGlnQVAB?hl=en-IN&gl=IN&ceid=IN%3Aen")
tech_news_soup=BeautifulSoup(tech_url.content,'html.parser')

tech_google_news = tech_news_soup.find_all('h3')


google_news_content=[]


for gn in tech_google_news :
    google_news_content.append(gn.text)
  
#print(google_news_content )

##########################################Entertainment News##############
entr_url=requests.get("https://news.google.com/topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNREpxYW5RU0FtVnVHZ0pKVGlnQVAB?hl=en-IN&gl=IN&ceid=IN%3Aen")
entr_news_soup=BeautifulSoup(entr_url.content,'html.parser')

#entr_google_news = entr_news_soup.find_all('h4',class_="ipQwMb ekueJc RD0gLb")
entr_google_news = entr_news_soup.find_all("h4")

google_news_entr=[]

for ge in entr_google_news :
    google_news_entr.append(ge.text)
  
#print(google_news_entr)

###################################Entertainnews for bbc news########
entr_gurl=requests.get("https://www.bbc.com/news/entertainment_and_arts")
entr_gnews_soup=BeautifulSoup(entr_gurl.content,'html.parser')

entr_gnews = entr_gnews_soup.find_all('h3')


gnews_entr=[]


for en in entr_gnews :
    gnews_entr.append(en.text)
  
#print(gnews_entr )

######################################### World News ##################

#--------------------- world news New York Times -------------------

wld_url=requests.get("https://www.nytimes.com/section/world")
wld_news_soup=BeautifulSoup(wld_url.content,'html.parser')

wld_news = wld_news_soup.find_all('h2')
news_wld=[]

for wn in wld_news :
    news_wld.append(wn.text)
  
#print(news_wld)

#------------------- world news google news -----------------
wld_gurl=requests.get("https://news.google.com/topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRGx1YlY4U0FtVnVHZ0pKVGlnQVAB?hl=en-IN&gl=IN&ceid=IN%3Aen")
wld_gnews_soup=BeautifulSoup(wld_gurl.content,'html.parser')

wld_gnews = wld_gnews_soup.find_all('h3')


gnews_wld=[]


for wn in wld_gnews :
    gnews_wld.append(wn.text)
  
#print(gnews_wld )

###################################################



def index(request):
    return render(request, 'index.html')    



def index(request):
    return render(request, 'news/index.html', {'toi_news':toi_news, 'zn_news': zn_news,'bb_news':bb_news})

def about(request):
    return render(request,'news/about.html',{})

def latestnews(request):
    return render(request,'news/latestnews.html',{'toi_news':toi_news, 'bb_news':bb_news})

def sports(request):
    return render(request,'news/sports.html',{'news_content':news_content,'news_bd_content':news_bd_content})   

def topstory(request):
    return render(request,'news/topstory.html',{'nd_news':nd_news,'to_news':to_news})     

def technews(request):
    return render(request,'news/technews.html',{'news_tech_content':news_tech_content,'google_news_content':google_news_content})


def entrnews(request):
    return render(request,'news/entrnews.html',{'google_news_entr':google_news_entr,'gnews_entr':gnews_entr})

def worldnews(request):
    return render(request,'news/worldnews.html',{'news_wld':news_wld,'gnews_wld':gnews_wld})    

def cont(request):
    return render(request,'news/cont.html',{})









